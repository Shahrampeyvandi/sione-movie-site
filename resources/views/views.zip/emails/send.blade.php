<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>

<body>
    {{$title}}
    <hr>
    {!!$content!!}


</body>

</html>